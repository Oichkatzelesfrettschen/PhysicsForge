# Sample Document

Governing Equation: E = mc^2
Prediction: ∇^2 φ = 0 in vacuum
H = T + V